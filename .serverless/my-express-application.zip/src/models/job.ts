export class Job {
    
}
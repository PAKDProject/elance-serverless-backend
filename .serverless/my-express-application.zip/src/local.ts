import { App } from "./lib/createServer";

new App(3000).startLocal()
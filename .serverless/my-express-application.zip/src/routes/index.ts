// All backend routes listed below
import { HelloController } from "./HelloController";
export default [
    new HelloController()
]